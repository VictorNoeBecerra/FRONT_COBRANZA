# PrimeVue Theming with SASS

Visit the [official documentation](https://primevue.org/theming/#customtheme) for more information.
